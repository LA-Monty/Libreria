<?php

//Conexion a la base de datos 
$conexion = new mysqli("localhost", "root", "", "libreria","3306");
$conexion->set_charset("utf8")
?>

<!--Cambios necesarios para no joder el repositorio-->